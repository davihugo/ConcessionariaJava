import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ConcessionariaGUI {

    private JPanel cards;
    private CardLayout cardLayout;
    private DefaultTableModel carroTableModel;
    private DefaultTableModel motoTableModel;
    private DefaultTableModel caminhaoTableModel;

    private JTable carroTable;
    private JTable motoTable;
    private JTable caminhaoTable;

    private List<Veiculo> veiculos;
    private int proximoId = 1;

    private JTextField idAtualizacaoField;
    private JTextField marcaAtualizacaoField;
    private JTextField modeloAtualizacaoField;
    private JTextField anoAtualizacaoField;
    private JTextField precoAtualizacaoField;
    private JTextField corAtualizacaoField;

    public ConcessionariaGUI() {
        JFrame frame = new JFrame("Concessionária de Veículos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);

        frame.add(cards);

        JButton carroButton = new JButton("Carro");
        JButton motoButton = new JButton("Moto");
        JButton caminhaoButton = new JButton("Caminhão");

        carroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cards, "CARRO");
            }
        });

        motoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cards, "MOTO");
            }
        });

        caminhaoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cards, "CAMINHAO");
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(carroButton);
        buttonPanel.add(motoButton);
        buttonPanel.add(caminhaoButton);

        JPanel carroPanel = criarFormulario("CARRO");
        JPanel motoPanel = criarFormulario("MOTO");
        JPanel caminhaoPanel = criarFormulario("CAMINHAO");

        cards.add(carroPanel, "CARRO");
        cards.add(motoPanel, "MOTO");
        cards.add(caminhaoPanel, "CAMINHAO");

        carroTableModel = new DefaultTableModel(new Object[]{"ID", "Marca", "Modelo", "Ano", "Preço", "Cor", "Número de Portas"}, 0);
        motoTableModel = new DefaultTableModel(new Object[]{"ID", "Marca", "Modelo", "Ano", "Preço", "Cor", "Cilindrada"}, 0);
        caminhaoTableModel = new DefaultTableModel(new Object[]{"ID", "Marca", "Modelo", "Ano", "Preço", "Cor", "Capacidade de Carga"}, 0);

        carroTable = new JTable(carroTableModel);
        motoTable = new JTable(motoTableModel);
        caminhaoTable = new JTable(caminhaoTableModel);

        JScrollPane carroTableScrollPane = new JScrollPane(carroTable);
        JScrollPane motoTableScrollPane = new JScrollPane(motoTable);
        JScrollPane caminhaoTableScrollPane = new JScrollPane(caminhaoTable);

        carroPanel.add(carroTableScrollPane);
        motoPanel.add(motoTableScrollPane);
        caminhaoPanel.add(caminhaoTableScrollPane);

        veiculos = new ArrayList<>();

        JPanel atualizacaoPanel = new JPanel(new GridLayout(0, 1));
        atualizacaoPanel.setBorder(BorderFactory.createTitledBorder("Atualização de Informações"));
        JLabel idAtualizacaoLabel = new JLabel("ID:");
        idAtualizacaoField = new JTextField(10);
        JLabel marcaAtualizacaoLabel = new JLabel("Nova Marca:");
        marcaAtualizacaoField = new JTextField(20);
        JLabel modeloAtualizacaoLabel = new JLabel("Novo Modelo:");
        modeloAtualizacaoField = new JTextField(20);
        JLabel anoAtualizacaoLabel = new JLabel("Novo Ano:");
        anoAtualizacaoField = new JTextField(10);
        JLabel precoAtualizacaoLabel = new JLabel("Novo Preço:");
        precoAtualizacaoField = new JTextField(10);
        JLabel corAtualizacaoLabel = new JLabel("Nova Cor:");
        corAtualizacaoField = new JTextField(20);

        JButton localizarButton = new JButton("Localizar Veículo");
        localizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idAtualizacaoField.getText());
                Veiculo veiculo = localizarVeiculoPorId(id);
                if (veiculo != null) {
                    marcaAtualizacaoField.setText(veiculo.getMarca());
                    modeloAtualizacaoField.setText(veiculo.getModelo());
                    anoAtualizacaoField.setText(String.valueOf(veiculo.getAno()));
                    precoAtualizacaoField.setText(String.valueOf(veiculo.getPreco()));
                    corAtualizacaoField.setText(veiculo.getCor());
                } else {
                    JOptionPane.showMessageDialog(null, "Veículo com ID " + id + " não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton atualizarButton = new JButton("Atualizar Veículo");
        atualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idAtualizacaoField.getText());
                Veiculo veiculo = localizarVeiculoPorId(id);
                if (veiculo != null) {
                    veiculo.setMarca(marcaAtualizacaoField.getText());
                    veiculo.setModelo(modeloAtualizacaoField.getText());
                    veiculo.setAno(Integer.parseInt(anoAtualizacaoField.getText()));
                    veiculo.setPreco(Double.parseDouble(precoAtualizacaoField.getText()));
                    veiculo.setCor(corAtualizacaoField.getText());
                    atualizarTabela();
                    limparCamposAtualizacao();
                } else {
                    JOptionPane.showMessageDialog(null, "Veículo com ID " + id + " não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton deletarButton = new JButton("Deletar Veículo");
        deletarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idAtualizacaoField.getText());
                Veiculo veiculo = localizarVeiculoPorId(id);
                if (veiculo != null) {
                    veiculos.remove(veiculo);
                    atualizarTabela();
                    limparCamposAtualizacao();
                } else {
                    JOptionPane.showMessageDialog(null, "Veículo com ID " + id + " não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        atualizacaoPanel.add(idAtualizacaoLabel);
        atualizacaoPanel.add(idAtualizacaoField);
        atualizacaoPanel.add(marcaAtualizacaoLabel);
        atualizacaoPanel.add(marcaAtualizacaoField);
        atualizacaoPanel.add(modeloAtualizacaoLabel);
        atualizacaoPanel.add(modeloAtualizacaoField);
        atualizacaoPanel.add(anoAtualizacaoLabel);
        atualizacaoPanel.add(anoAtualizacaoField);
        atualizacaoPanel.add(precoAtualizacaoLabel);
        atualizacaoPanel.add(precoAtualizacaoField);
        atualizacaoPanel.add(corAtualizacaoLabel);
        atualizacaoPanel.add(corAtualizacaoField);
        atualizacaoPanel.add(localizarButton);
        atualizacaoPanel.add(atualizarButton);
        atualizacaoPanel.add(deletarButton);

        frame.add(atualizacaoPanel, BorderLayout.EAST);

        frame.add(buttonPanel, BorderLayout.NORTH);
        frame.add(cards, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    private JPanel criarFormulario(String veiculo) {
        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Cadastro de " + veiculo));

        JLabel marcaLabel = new JLabel("Marca:");
        JTextField marcaField = new JTextField(20);
        JLabel modeloLabel = new JLabel("Modelo:");
        JTextField modeloField = new JTextField(20);
        JLabel anoLabel = new JLabel("Ano:");
        JTextField anoField = new JTextField(10);
        JLabel precoLabel = new JLabel("Preço:");
        JTextField precoField = new JTextField(10);
        JLabel corLabel = new JLabel("Cor:");
        JTextField corField = new JTextField(20);

        JTextField numeroPortasField = new JTextField(10);
        JTextField cilindradaField = new JTextField(10);
        JTextField capacidadeCargaField = new JTextField(10);

        if (veiculo.equals("CARRO")) {
            JLabel numeroPortasLabel = new JLabel("Número de Portas:");
            panel.add(numeroPortasLabel);
            panel.add(numeroPortasField);
        } else if (veiculo.equals("MOTO")) {
            JLabel cilindradaLabel = new JLabel("Cilindrada:");
            panel.add(cilindradaLabel);
            panel.add(cilindradaField);
        } else if (veiculo.equals("CAMINHAO")) {
            JLabel capacidadeCargaLabel = new JLabel("Capacidade de Carga:");
            panel.add(capacidadeCargaLabel);
            panel.add(capacidadeCargaField);
        }

        JButton adicionarButton = new JButton("Adicionar");
        adicionarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = marcaField.getText();
                String modelo = modeloField.getText();
                int ano = Integer.parseInt(anoField.getText());
                double preco = Double.parseDouble(precoField.getText());
                String cor = corField.getText();

                if (veiculo.equals("CARRO")) {
                    int numeroPortas = Integer.parseInt(numeroPortasField.getText());
                    Carro novoCarro = new Carro(proximoId, marca, modelo, ano, preco, numeroPortas, cor);
                    veiculos.add(novoCarro);
                    carroTableModel.addRow(new Object[]{proximoId, marca, modelo, ano, preco, cor, numeroPortas});
                } else if (veiculo.equals("MOTO")) {
                    String cilindrada = cilindradaField.getText();
                    Moto novaMoto = new Moto(proximoId, marca, modelo, ano, preco, cilindrada, cor);
                    veiculos.add(novaMoto);
                    motoTableModel.addRow(new Object[]{proximoId, marca, modelo, ano, preco, cor, cilindrada});
                } else if (veiculo.equals("CAMINHAO")) {
                    int capacidadeCarga = Integer.parseInt(capacidadeCargaField.getText());
                    Caminhao novoCaminhao = new Caminhao(proximoId, marca, modelo, ano, preco, capacidadeCarga, cor);
                    veiculos.add(novoCaminhao);
                    caminhaoTableModel.addRow(new Object[]{proximoId, marca, modelo, ano, preco, cor, capacidadeCarga});
                }

                marcaField.setText("");
                modeloField.setText("");
                anoField.setText("");
                precoField.setText("");
                corField.setText("");

                if (veiculo.equals("CARRO")) {
                    numeroPortasField.setText("");
                } else if (veiculo.equals("MOTO")) {
                    cilindradaField.setText("");
                } else if (veiculo.equals("CAMINHAO")) {
                    capacidadeCargaField.setText("");
                }

                proximoId++;
            }
        });

        panel.add(marcaLabel);
        panel.add(marcaField);
        panel.add(modeloLabel);
        panel.add(modeloField);
        panel.add(anoLabel);
        panel.add(anoField);
        panel.add(precoLabel);
        panel.add(precoField);
        panel.add(corLabel);
        panel.add(corField);
        panel.add(adicionarButton);

        return panel;
    }

    private Veiculo localizarVeiculoPorId(int id) {
        for (Veiculo veiculo : veiculos) {
            if (veiculo.getId() == id) {
                return veiculo;
            }
        }
        return null;
    }

    private void atualizarTabela() {
        carroTableModel.setRowCount(0);
        motoTableModel.setRowCount(0);
        caminhaoTableModel.setRowCount(0);

        for (Veiculo veiculo : veiculos) {
            if (veiculo instanceof Carro) {
                carroTableModel.addRow(new Object[]{veiculo.getId(), veiculo.getMarca(), veiculo.getModelo(), veiculo.getAno(), veiculo.getPreco(), veiculo.getCor(), ((Carro) veiculo).getNumeroPortas()});
            } else if (veiculo instanceof Moto) {
                motoTableModel.addRow(new Object[]{veiculo.getId(), veiculo.getMarca(), veiculo.getModelo(), veiculo.getAno(), veiculo.getPreco(), veiculo.getCor(), ((Moto) veiculo).getCilindrada()});
            } else if (veiculo instanceof Caminhao) {
                caminhaoTableModel.addRow(new Object[]{veiculo.getId(), veiculo.getMarca(), veiculo.getModelo(), veiculo.getAno(), veiculo.getPreco(), veiculo.getCor(), ((Caminhao) veiculo).getCapacidadeCarga()});
            }
        }
    }

    private void limparCamposAtualizacao() {
        idAtualizacaoField.setText("");
        marcaAtualizacaoField.setText("");
        modeloAtualizacaoField.setText("");
        anoAtualizacaoField.setText("");
        precoAtualizacaoField.setText("");
        corAtualizacaoField.setText("");
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ConcessionariaGUI();
            }
        });
    }
}

class Veiculo {
    private int id;
    private String tipo;
    private String marca;
    private String modelo;
    private int ano;
    private double preco;
    private String cor;

    public Veiculo(int id, String tipo, String marca, String modelo, int ano, double preco, String cor) {
        this.id = id;
        this.tipo = tipo;
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.preco = preco;
        this.cor = cor;
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
}

class Carro extends Veiculo {
    private int numeroPortas;

    public Carro(int id, String marca, String modelo, int ano, double preco, int numeroPortas, String cor) {
        super(id, "Carro", marca, modelo, ano, preco, cor);
        this.numeroPortas = numeroPortas;
    }

    public int getNumeroPortas() {
        return numeroPortas;
    }
}

class Moto extends Veiculo {
    private String cilindrada;

    public Moto(int id, String marca, String modelo, int ano, double preco, String cilindrada, String cor) {
        super(id, "Moto", marca, modelo, ano, preco, cor);
        this.cilindrada = cilindrada;
    }

    public String getCilindrada() {
        return cilindrada;
    }
}

class Caminhao extends Veiculo {
    private int capacidadeCarga;

    public Caminhao(int id, String marca, String modelo, int ano, double preco, int capacidadeCarga, String cor) {
        super(id, "Caminhao", marca, modelo, ano, preco, cor);
        this.capacidadeCarga = capacidadeCarga;
    }

    public int getCapacidadeCarga() {
        return capacidadeCarga;
    }
}
