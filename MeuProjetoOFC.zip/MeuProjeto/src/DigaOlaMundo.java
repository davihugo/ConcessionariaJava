public class DigaOlaMundo {
    public static void main (String args []) {
        System.out.println("ola mundo");
        System.out.println("ola mundo");
    }
}
